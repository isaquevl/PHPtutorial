<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

</body>
<?php 
echo "Welcome Home!";

$txt = "W3Schools.com";
echo "I love " . $txt . "!";

var_dump(5);
var_dump("John");
var_dump(3.14);
var_dump(true);
var_dump([2, 3, 56]);
var_dump(NULL);

$x = "John";
echo $x;

$x = $y = $z = "Fruit";



$x = 5; // global scope

function myTesto() {
  // using x inside this function will generate an error
  echo "<p>Variable x inside function is:</p>";
}
myTesto();

echo "<p>Variable x outside function is: $x</p>";  

function myTes() {
    $x = 5; // local scope
    echo "<p>Variable x inside function is: $x</p>";
  }
  myTesto();
  
  // using x outside the function will generate an error
  echo "<p>Variable x outside function is: $x</p>";


  $x = 5;
$y = 10;

function myTest() {
  $GLOBALS['y'] = $GLOBALS['x'] + $GLOBALS['y'];
}

myTest();
echo $y; // outputs 15

function myTesti() {
    static $x = 0;
    echo $x;
    $x++;
  }
  
  myTesti();
  myTesti();
  myTesti();

  echo "<h2>PHP is Fun!</h2>";
echo "Hello world!<br>";
echo "I'm about to learn PHP!<br>";
echo "This ", "string ", "was ", "made ", "with multiple parameters.";

$txt1 = "Learn PHP";
$txt2 = "W3Schools.com";

echo "<h2>$txt1</h2>";
echo "<p>Study PHP at $txt2</p>";

?>

</html>